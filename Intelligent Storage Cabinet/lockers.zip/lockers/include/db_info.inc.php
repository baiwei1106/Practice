<?php @session_start();
	ini_set("display_errors","Off"); 
	ini_set("session.cookie_httponly", 1);   
	header('X-Frame-Options:SAMEORIGIN');


static 	$DB_HOST="192.144.153.235";
static 	$DB_NAME="lockers";
static 	$DB_USER="root";
static 	$DB_PASS="bw661102";

?>
