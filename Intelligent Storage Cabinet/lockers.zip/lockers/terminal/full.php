<div class="main1">
    <div class="img"><img src="img/0.png" width="200px"></div>
    <div class="massage">暂无空闲柜可用，请稍后再试！<!--<button class="admin1">存包</button>--></div>
</div>
<div class="fooder">
    <span><span id="msc">30</span>秒后自动返回首页！</span>
</div>
</body>
</html>