
<div class="main1">
    <div class="img"><img src="img/3.png" width="200px"></div>
    <div class="massage">存包成功！请记录您的取包验证码是"<?php echo $iuser;?>"，如果忘记密码请联系管理员！<!--<button class="admin1">存包</button>--></div>
</div>
<div class="fooder">
    <span><span id="ny30">30</span>秒后自动返回首页！</span>
</div>
</body>
</html>