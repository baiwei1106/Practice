
<div class="main1">
    <div class="img"><img src="img/1.png" width="200px"></div>
    <div class="massage">请稍等！<!--<button class="admin1">存包</button>--></div>
    <?php require('reload.php'); ?>
</div>
<div class="fooder">
    <!-- <span><span id="msc">10</span>秒后自动返回首页！</span> -->
</div>
</body>
</html>