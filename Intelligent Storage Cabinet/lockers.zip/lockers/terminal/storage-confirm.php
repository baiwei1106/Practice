

<div class="main1">
    <div class="img"><img src="img/0.png" width="200px"></div>
    <div class="massage">请按“存包”键存包！<?php echo "<button type=button class=admin1 id=go onclick=fun(1,".$box_id.",".$iuser.")>存包</button>"; ?></div>
</div>
<div class="fooder">
    <span><span id="msc">30</span>秒后自动返回首页！</span>
</div>
</body>
</html>