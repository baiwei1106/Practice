

<div class="main1">
    <div class="img"><img src="img/4.png" width="200px"></div>
    <div class="massage">验证码错误，请重新输入！<!--<button class="admin1">存包</button>--></div>
</div>
<div class="fooder">
    <span><span id="msc">30</span>秒后自动返回首页！</span>
</div>
</body>
</html>