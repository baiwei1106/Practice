    <div id="login" class="login">
        <div id="logo" class="logo">
            <img src="img/1.png" width="110px" />
        </div>
        <div class="trip">
            <span>
                请稍等！
            </span>
        </div>
        <?php require('reload.php'); ?>
    </div>
</div>