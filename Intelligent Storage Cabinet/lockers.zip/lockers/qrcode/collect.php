    <div id="login" class="login">
        <div id="logo" class="logo">
            <img src="img/0.png" width="110px" />
        </div>
        <div class="trip">
            <span>
                请按“取包”键取包！
            </span>
        </div>
        <div align="center">
            <?php echo "<button type=button class=btn id=go onclick=fun(2,".$box_id.",\"".$user_id."\")>取包</button>"; ?>
        </div>

    </div>
</div>