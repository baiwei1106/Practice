    <div id="login" class="login">
        <div id="logo" class="logo">
            <img src="img/4.png" width="110px" />
        </div>
        <div class="trip">
            <span>
                此柜已停用！
            </span>
        </div>
    </div>
</div>