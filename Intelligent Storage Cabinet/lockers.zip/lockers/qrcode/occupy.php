    <div id="login" class="login">
        <div id="logo" class="logo">
            <img src="img/2.png" width="110px" />
        </div>
        <div class="trip">
            <span>
                此柜已被占用，请使用其他柜！
            </span>
        </div>
    </div>
</div>