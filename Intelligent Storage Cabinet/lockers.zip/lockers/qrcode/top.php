<div id="content" class="content">
<div id="top" class="top">
    <div class="text" align="center">智能储物柜&nbsp;</div>
    <div class="text1" style="font-size: 14px;"><?php echo $box_id; ?>号柜</div>
</div>