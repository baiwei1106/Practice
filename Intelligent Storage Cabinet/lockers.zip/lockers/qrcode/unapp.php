    <div id="login" class="login">
        <div id="logo" class="logo">
            <img src="img/2.png" width="110px" />
        </div>
        <div class="trip">
            <span>
                请使用APP扫码存包！
            </span>
        </div>
    </div>
</div>