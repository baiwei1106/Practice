    <div id="login" class="login">
        <div id="logo" class="logo">
            <img src="img/3.png" width="110px" />
        </div>
        <div class="trip">
            <span>
                存包成功！
            </span>
        </div>
    </div>
</div>