<div id="content" class="content">
<div id="top" class="top">
    <div class="text" align="center">智能储物柜&nbsp;</div>
</div>